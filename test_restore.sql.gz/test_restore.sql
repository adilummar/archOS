--
-- PostgreSQL database dump
--

\restrict tCkD6cIffsebCOUzBscNtt4iHd09ADoteFuuWQx5vB6aaGryvd8Rj9EJ059ZQIj

-- Dumped from database version 16.15
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActivityLog; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."ActivityLog" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    "userId" text,
    "projectId" text,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    action text NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public."ActivityLog" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."ActivityLog" OWNER TO elscore;

--
-- Name: AttendanceSession; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."AttendanceSession" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    "userId" text NOT NULL,
    date text NOT NULL,
    "checkInTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "checkOutTime" timestamp(3) without time zone,
    status text DEFAULT 'working'::text NOT NULL,
    "currentProjectId" text,
    "currentTaskId" text,
    "totalWorkMinutes" integer DEFAULT 0 NOT NULL,
    "totalBreakMinutes" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public."AttendanceSession" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."AttendanceSession" OWNER TO elscore;

--
-- Name: BreakRecord; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."BreakRecord" (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "startTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endTime" timestamp(3) without time zone,
    "durationMinutes" integer
);

ALTER TABLE ONLY public."BreakRecord" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."BreakRecord" OWNER TO elscore;

--
-- Name: Client; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    name text NOT NULL,
    company text,
    phone text,
    email text NOT NULL,
    address text,
    gstin text,
    "portalEnabled" boolean DEFAULT false NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public."Client" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."Client" OWNER TO elscore;

--
-- Name: Firm; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."Firm" (
    id text NOT NULL,
    name text NOT NULL,
    logo text,
    address text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    gstin text,
    website text,
    "planType" text DEFAULT 'starter'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    slug text DEFAULT ''::text NOT NULL,
    "priorityPeriodDays" integer DEFAULT 7 NOT NULL,
    "minimumTaskLeadTimeDays" integer DEFAULT 3 NOT NULL,
    "enabledFeatures" text[] DEFAULT ARRAY['DASHBOARD'::text, 'PROJECTS'::text, 'TASKS'::text, 'STAFF'::text, 'ATTENDANCE'::text],
    "onboardingState" text DEFAULT 'NOT_STARTED'::text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL
);

ALTER TABLE ONLY public."Firm" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."Firm" OWNER TO elscore;

--
-- Name: PlatformAdmin; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."PlatformAdmin" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public."PlatformAdmin" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."PlatformAdmin" OWNER TO elscore;

--
-- Name: Project; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    "clientId" text,
    name text NOT NULL,
    "clientName" text,
    status text DEFAULT 'active'::text NOT NULL,
    "teamLeadId" text,
    location text,
    "startDate" timestamp(3) without time zone,
    "expectedEndDate" timestamp(3) without time zone,
    "actualEndDate" timestamp(3) without time zone,
    "projectValue" double precision,
    "feeAgreed" double precision,
    "feeStructure" text,
    description text,
    "fileRequestWindowDays" integer DEFAULT 7 NOT NULL,
    "chatEnabled" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "templateId" text
);

ALTER TABLE ONLY public."Project" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."Project" OWNER TO elscore;

--
-- Name: ProjectStaff; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."ProjectStaff" (
    "projectId" text NOT NULL,
    "userId" text NOT NULL
);

ALTER TABLE ONLY public."ProjectStaff" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."ProjectStaff" OWNER TO elscore;

--
-- Name: ProjectStage; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."ProjectStage" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    name text NOT NULL,
    "order" integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "isClientApprovalRequired" boolean DEFAULT false NOT NULL,
    "clientApprovalStatus" text,
    "clientApprovalNote" text,
    "clientApprovedAt" timestamp(3) without time zone,
    "startDate" timestamp(3) without time zone,
    "plannedEndDate" timestamp(3) without time zone,
    "actualEndDate" timestamp(3) without time zone,
    description text,
    "isCustom" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public."ProjectStage" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."ProjectStage" OWNER TO elscore;

--
-- Name: ProjectTemplate; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."ProjectTemplate" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    name text NOT NULL,
    description text,
    "feeStructure" text DEFAULT 'per_stage'::text NOT NULL,
    "defaultFileRequestWindowDays" integer DEFAULT 7 NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public."ProjectTemplate" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."ProjectTemplate" OWNER TO elscore;

--
-- Name: Subtask; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."Subtask" (
    id text NOT NULL,
    "taskId" text NOT NULL,
    title text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    "createdById" text NOT NULL,
    "assignedToId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);

ALTER TABLE ONLY public."Subtask" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."Subtask" OWNER TO elscore;

--
-- Name: Task; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    "projectId" text NOT NULL,
    "stageId" text,
    "assigneeId" text NOT NULL,
    "assignerId" text NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'todo'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "startDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "approvalStatus" text,
    "approvalNote" text,
    "approvedById" text,
    "isBlocked" boolean DEFAULT false NOT NULL,
    "blockedReason" text,
    tags text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "order" integer DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public."Task" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."Task" OWNER TO elscore;

--
-- Name: TaskAssignmentOverride; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."TaskAssignmentOverride" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    "taskId" text NOT NULL,
    "teamLeadId" text NOT NULL,
    "assigneeId" text NOT NULL,
    "requestedDueDate" timestamp(3) without time zone NOT NULL,
    "requiredLeadTimeDays" integer NOT NULL,
    "actualLeadTimeDays" integer NOT NULL,
    reason text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public."TaskAssignmentOverride" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."TaskAssignmentOverride" OWNER TO elscore;

--
-- Name: TaskReviewCycle; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."TaskReviewCycle" (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "reviewerId" text NOT NULL,
    "revisionNumber" integer NOT NULL,
    remark text NOT NULL,
    "statusRequested" text NOT NULL,
    "previousDueDate" timestamp(3) without time zone,
    "requestedDueDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public."TaskReviewCycle" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."TaskReviewCycle" OWNER TO elscore;

--
-- Name: TaskTimeSegment; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."TaskTimeSegment" (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "projectId" text NOT NULL,
    "taskId" text NOT NULL,
    "startTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endTime" timestamp(3) without time zone,
    "durationMinutes" integer,
    "taskCompletedOnSwitch" boolean DEFAULT false NOT NULL
);

ALTER TABLE ONLY public."TaskTimeSegment" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."TaskTimeSegment" OWNER TO elscore;

--
-- Name: TemplateStage; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."TemplateStage" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    name text NOT NULL,
    "order" integer NOT NULL,
    "defaultDurationDays" integer DEFAULT 7 NOT NULL,
    description text,
    "isClientApprovalRequired" boolean DEFAULT false NOT NULL,
    "isPaymentMilestone" boolean DEFAULT false NOT NULL,
    "paymentPercentage" double precision,
    "drawingTypesExpected" text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public."TemplateStage" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."TemplateStage" OWNER TO elscore;

--
-- Name: TemplateTask; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."TemplateTask" (
    id text NOT NULL,
    "stageId" text NOT NULL,
    title text NOT NULL,
    description text,
    "order" integer NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public."TemplateTask" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."TemplateTask" OWNER TO elscore;

--
-- Name: TimeLog; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."TimeLog" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    "userId" text NOT NULL,
    "projectId" text NOT NULL,
    phase text,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone,
    "durationMinutes" integer,
    notes text,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isEdited" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public."TimeLog" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."TimeLog" OWNER TO elscore;

--
-- Name: User; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "firmId" text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    role text NOT NULL,
    designation text,
    "avatarInitials" text,
    "avatarColor" text,
    "costRatePerHour" double precision DEFAULT 0 NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "discontinuedAt" timestamp(3) without time zone,
    "passwordHash" text
);

ALTER TABLE ONLY public."User" FORCE ROW LEVEL SECURITY;


ALTER TABLE public."User" OWNER TO elscore;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: elscore
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO elscore;

--
-- Data for Name: ActivityLog; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."ActivityLog" (id, "firmId", "userId", "projectId", entity, "entityId", action, description, "createdAt") FROM stdin;
0e869255-5db7-4ae5-bbee-e66e99e9b327	firm-coastal-001	user-adil-001	project-villa-001	project	project-villa-001	created	Project "Harish Kumar Residence — Tripunithura" was created	2026-06-01 09:00:00
1cde7adf-ab24-4f5b-b891-d1f0c08fb688	firm-coastal-001	user-priya-001	project-villa-001	stage	stage-001	status_changed	Stage "Schematic Design" moved to completed	2026-07-28 15:30:00
2e91c55a-5b7a-4df0-a66d-92b4937d8692	firm-coastal-001	user-rahul-001	project-villa-001	task	task-005	status_changed	Task "Site visit and measurements verification" moved from in_progress → done	2026-09-09 11:00:00
7bbb1b61-fba6-4451-8100-4241cc8d9762	firm-coastal-001	user-priya-001	project-villa-001	task	task-001	created	Task "Prepare floor plan drawings — Ground Floor" created and assigned to Rahul Menon	2026-09-12 10:00:00
8726054f-c81a-4d88-9785-208ecf40c3d9	firm-coastal-001	user-ananya-001	project-villa-001	task	task-003	status_changed	Task "Interior material mood board" moved from in_progress → review	2026-09-18 16:45:00
a7bd71ba-b9da-49cb-aa57-74e26c6264ed	firm-coastal-001	user-adil-001	\N	user	user-ananya-001	created	Staff member Ananya Krishnan added to the firm	2026-06-05 09:00:00
980cbe0f-4cf9-4806-a93d-f98b68acc003	firm-coastal-001	user-adil-001	project-villa-001	project	project-villa-001	created	Project "Harish Kumar Residence — Tripunithura" was created	2026-06-01 09:00:00
143024d5-2027-4485-8a6e-2b7bba355df7	firm-coastal-001	user-priya-001	project-villa-001	stage	stage-001	status_changed	Stage "Schematic Design" moved to completed	2026-07-28 15:30:00
bb5eb567-38a9-4324-b167-cdc76a16177f	firm-coastal-001	user-rahul-001	project-villa-001	task	task-005	status_changed	Task "Site visit and measurements verification" moved from in_progress → done	2026-09-09 11:00:00
70298829-8817-4cf6-bbe0-72957ef01636	firm-coastal-001	user-priya-001	project-villa-001	task	task-001	created	Task "Prepare floor plan drawings — Ground Floor" created and assigned to Rahul Menon	2026-09-12 10:00:00
7571d676-a7dc-476f-ba24-2b7411cf7d56	firm-coastal-001	user-ananya-001	project-villa-001	task	task-003	status_changed	Task "Interior material mood board" moved from in_progress → review	2026-09-18 16:45:00
53941ed3-1964-492f-af1d-45417e8f7858	firm-coastal-001	user-adil-001	\N	user	user-ananya-001	created	Staff member Ananya Krishnan added to the firm	2026-06-05 09:00:00
100b2aab-941d-4fd3-ab30-e329c9c935d6	firm-coastal-001	user-adil-001	project-villa-001	project	project-villa-001	created	Project "Harish Kumar Residence — Tripunithura" was created	2026-06-01 09:00:00
1ae9dc3a-37b3-44b4-8f64-2f608a6ba19f	firm-coastal-001	user-priya-001	project-villa-001	stage	stage-001	status_changed	Stage "Schematic Design" moved to completed	2026-07-28 15:30:00
f7445743-4a58-456f-80a7-9208ceb0cba1	firm-coastal-001	user-rahul-001	project-villa-001	task	task-005	status_changed	Task "Site visit and measurements verification" moved from in_progress → done	2026-09-09 11:00:00
284b2471-6aa1-4b15-8cc3-0320aacb7bda	firm-coastal-001	user-priya-001	project-villa-001	task	task-001	created	Task "Prepare floor plan drawings — Ground Floor" created and assigned to Rahul Menon	2026-09-12 10:00:00
58e7939f-c5e9-468b-bcb4-2bc050bea7e3	firm-coastal-001	user-ananya-001	project-villa-001	task	task-003	status_changed	Task "Interior material mood board" moved from in_progress → review	2026-09-18 16:45:00
27cd8cf7-bf1e-4fff-88fa-6e2699d674b4	firm-coastal-001	user-adil-001	\N	user	user-ananya-001	created	Staff member Ananya Krishnan added to the firm	2026-06-05 09:00:00
5be5f6a7-6ba8-4d86-a519-c875d8b7f147	firm-coastal-001	user-priya-001	project-villa-001	attendance	883424bd-4124-474e-976c-7ce06f4a8d4a	checked_in	Checked in and started working	2026-09-20 01:53:40.449
81059059-0143-4235-b432-a0a5aabc19fe	firm-coastal-001	user-adil-001	project-villa-001	task	8ddd51d4-8153-45e6-886d-7456b34cb145	created	Task "design" created and assigned to Adil Rahman	2026-09-21 13:56:00.923
902b155b-c074-4cef-8415-7e9368a825b6	firm-coastal-001	user-adil-001	project-villa-002	task	task2-001	submitted_for_review	Task submitted for review	2026-10-01 11:25:32.995
788b1751-612f-4530-886d-960eff0d090b	firm-coastal-001	user-adil-001	project-villa-002	task	task2-001	revision_requested	Revision requested for task	2026-10-01 11:30:23.323
6faf1849-df90-4480-a308-738928f67ded	firm-coastal-001	user-adil-001	project-villa-002	task	task2-001	submitted_for_review	Task submitted for review	2026-10-01 11:30:23.432
59ae698c-967b-4e9a-b32c-6a7126bb7e7b	firm-coastal-001	user-adil-001	project-villa-002	task	task2-001	approved	Task approved and completed	2026-10-01 11:30:24.711
500d6986-9774-4212-8d6a-d35933630e63	firm-coastal-001	user-priya-001	project-villa-001	task	191d8f31-f724-4b6f-a8eb-ededabe53dce	created	Task created	2026-10-01 11:59:38.987
4dbabfef-0606-4176-8561-d5b6c3fcbe75	firm-coastal-001	user-rahul-001	project-villa-001	task	191d8f31-f724-4b6f-a8eb-ededabe53dce	deleted	Task deleted	2026-10-01 11:59:39.507
37c9a5de-300a-4688-abdf-a04aaf2955eb	firm-coastal-001	user-priya-001	project-villa-001	task	585d597b-2c30-412d-a8a6-4882c8557ff1	created	Task created	2026-10-01 11:59:51.451
1460480d-5f7f-4724-aaa5-834aa2eb6330	firm-coastal-001	user-rahul-001	project-villa-001	attendance	9d8d36f0-c545-4086-9cc5-81c0a4a2f31e	checked_in	Checked in and started working	2026-10-01 12:03:59.258
8774f861-a5fc-4b09-a732-b1516114d843	firm-coastal-001	user-priya-001	project-villa-001	task	abfdd9f7-ce2e-4d6b-85fc-eefbb7b0b26d	created	Task created	2026-10-01 13:32:39.04
\.


--
-- Data for Name: AttendanceSession; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."AttendanceSession" (id, "firmId", "userId", date, "checkInTime", "checkOutTime", status, "currentProjectId", "currentTaskId", "totalWorkMinutes", "totalBreakMinutes", "createdAt", "updatedAt") FROM stdin;
021a8c9b-bdf1-448d-baf6-4d907373b36a	firm-coastal-001	user-priya-001	2026-09-19	2026-09-19 11:44:00.364	2026-09-19 11:46:12.856	checked_out	p-rameshan-villa	t-rv-005	1	0	2026-09-19 11:44:00.366	2026-09-19 11:46:12.897
883424bd-4124-474e-976c-7ce06f4a8d4a	firm-coastal-001	user-priya-001	2026-09-20	2026-09-20 01:53:40.366	\N	on_break	project-villa-001	task-006	0	0	2026-09-20 01:53:40.373	2026-09-20 02:27:51.463
9d8d36f0-c545-4086-9cc5-81c0a4a2f31e	firm-coastal-001	user-rahul-001	2026-10-01	2026-10-01 12:03:59.229	\N	working	project-villa-001	task2-001	0	0	2026-10-01 12:03:59.23	2026-10-01 12:03:59.23
\.


--
-- Data for Name: BreakRecord; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."BreakRecord" (id, "sessionId", "startTime", "endTime", "durationMinutes") FROM stdin;
ab46d95b-1bca-46ef-bc2d-cb0eb92a06be	883424bd-4124-474e-976c-7ce06f4a8d4a	2026-09-20 02:27:51.395	\N	\N
\.


--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."Client" (id, "firmId", name, company, phone, email, address, gstin, "portalEnabled", notes, "createdAt") FROM stdin;
client-harish-001	firm-coastal-001	Harish Kumar	Kumar Constructions Pvt Ltd	+91 94470 88001	harish@kumarconstructions.in	45, Palarivattom, Ernakulam, Kerala 682025	\N	t	\N	2026-09-19 11:10:18.231
client-rameshan-001	firm-coastal-001	Rameshan Pillai	Pillai Builders	+91 94470 88002	rameshan@pillaibuilders.in	12, Peroorkada, Thiruvananthapuram, Kerala 695005	\N	t	\N	2026-09-20 01:34:17.897
\.


--
-- Data for Name: Firm; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."Firm" (id, name, logo, address, phone, email, gstin, website, "planType", "createdAt", slug, "priorityPeriodDays", "minimumTaskLeadTimeDays", "enabledFeatures", "onboardingState", status) FROM stdin;
3d6a546c-9ddb-4683-98d8-c77d497f17b3	Test Firm B	\N	123 Test	1234567890	testb@example.com	\N	\N	starter	2026-09-25 09:25:22.54	firm-b	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
firm-coastal-001	Coastal Design Associates	\N	kannur thavakkara	9562521232	hello@coastaldesign.in	32AABCC1234F1ZX	https://coastaldesign.in	starter	2026-09-19 11:10:18.084	cda	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	COMPLETED	ACTIVE
12f2902c-4a36-45c8-960f-644a4814726b	Firm A	\N	TBD	TBD	admin@firma.com	\N	\N	starter	2026-10-01 11:48:30.959	firm-a	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
8ded49d6-a655-492f-abe9-e742b6e712da	Firm A1790855323095	\N	TBD	TBD	1790855323095admin@firma.com	\N	\N	starter	2026-10-01 11:48:43.129	firm-a-1790855323095	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
2d535cc2-3768-4085-a7f3-fe7fa8dbafe1	Firm B1790855323226	\N	TBD	TBD	1790855323226admin@firmb.com	\N	\N	starter	2026-10-01 11:48:43.273	firm-b-1790855323226	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
18c9abb8-c581-4ea4-bc7f-08e799dd0350	Firm A	\N	TBD	TBD	1790855347790admin@firma.com	\N	\N	starter	2026-10-01 11:49:07.833	firm-a-1790855347790	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
a9bb115d-1443-4a14-996b-cec1e7f99ff8	Firm B	\N	TBD	TBD	1790855347790admin@firmb.com	\N	\N	starter	2026-10-01 11:49:07.973	firm-b-1790855347934	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
398e6257-48e3-46f6-9ee7-20836445fa1e	Firm A	\N	TBD	TBD	1790855386273admin@firma.com	\N	\N	starter	2026-10-01 11:49:46.317	firm-a-1790855386273	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
b30a3b11-d824-41a0-874f-e13359a10e8b	Firm B	\N	TBD	TBD	1790855386273admin@firmb.com	\N	\N	starter	2026-10-01 11:49:46.507	firm-b-1790855386448	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
fe687734-8744-4465-a431-2ea9a8a37993	Firm A	\N	TBD	TBD	1790855407607admin@firma.com	\N	\N	starter	2026-10-01 11:50:07.665	firm-a-1790855407607	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
70ea055b-34ec-4175-99de-ef5bf2664253	Firm A	\N	TBD	TBD	1790855441210admin@firma.com	\N	\N	starter	2026-10-01 11:50:41.271	firm-a-1790855441210	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
f3b8bc69-99dd-44d7-86f7-0788341cfb28	Firm A	\N	TBD	TBD	1790855472920admin@firma.com	\N	\N	starter	2026-10-01 11:51:12.967	firm-a-1790855472920	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
382d5aa0-c313-4dee-adc9-c9b7d9c94bfd	Firm A	\N	TBD	TBD	1790855491803admin@firma.com	\N	\N	starter	2026-10-01 11:51:31.862	firm-a-1790855491803	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
7a5513a8-2f10-4ad9-a6b3-7e61b21c13d7	Firm A	\N	TBD	TBD	1790855515562admin@firma.com	\N	\N	starter	2026-10-01 11:51:55.67	firm-a-1790855515562	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
8f7d683d-ea3f-47d6-81d0-cc423955f3a3	Firm A	\N	TBD	TBD	1790861553748admin@firma.com	\N	\N	starter	2026-10-01 13:32:34.089	firm-a-1790861553748	7	3	{DASHBOARD,PROJECTS,TASKS,STAFF,ATTENDANCE}	NOT_STARTED	ACTIVE
\.


--
-- Data for Name: PlatformAdmin; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."PlatformAdmin" (id, email, "passwordHash", name, active, "createdAt", "updatedAt") FROM stdin;
f75e5f65-676a-4a0c-b853-cbd27fdf7b90	super@archos.com	$2b$10$PGyq.eqaLPVhfdl.ZrdjOu5iqZNs12eHZyKYcetcE2iCol38LwFG6	Initial Super Admin	t	2026-09-25 09:31:01.976	2026-10-01 11:48:25.736
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."Project" (id, "firmId", "clientId", name, "clientName", status, "teamLeadId", location, "startDate", "expectedEndDate", "actualEndDate", "projectValue", "feeAgreed", "feeStructure", description, "fileRequestWindowDays", "chatEnabled", "createdAt", "updatedAt", "templateId") FROM stdin;
project-villa-002	firm-coastal-001	client-rameshan-001	Rameshan Villa — Thiruvananthapuram	Rameshan Pillai	active	user-adil-001	Peroorkada, Thiruvananthapuram, Kerala	2026-08-01 00:00:00	2027-06-30 00:00:00	\N	15000000	1800000	lump_sum	3-storey contemporary villa. Built-up area: 4200 sqft.	7	t	2026-09-20 01:34:17.91	2026-09-20 01:34:17.91	\N
project-villa-001	firm-coastal-001	client-harish-001	Hacked!	Harish Kumar	active	user-priya-001	Tripunithura, Ernakulam, Kerala	2026-06-01 00:00:00	2027-03-31 00:00:00	\N	12000000	1500000	per_stage	4BHK luxury residence with traditional Kerala architecture influence and modern interiors. Site area: 10 cents. Built-up area: 3200 sqft.	7	t	2026-09-19 11:10:18.252	2026-10-01 11:52:17.831	\N
\.


--
-- Data for Name: ProjectStaff; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."ProjectStaff" ("projectId", "userId") FROM stdin;
project-villa-001	user-adil-001
project-villa-001	user-priya-001
project-villa-001	user-rahul-001
project-villa-001	user-ananya-001
project-villa-002	user-adil-001
project-villa-002	user-meera-001
project-villa-002	user-faiz-001
project-villa-002	user-sanjay-001
\.


--
-- Data for Name: ProjectStage; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."ProjectStage" (id, "projectId", name, "order", status, "isClientApprovalRequired", "clientApprovalStatus", "clientApprovalNote", "clientApprovedAt", "startDate", "plannedEndDate", "actualEndDate", description, "isCustom", "createdAt") FROM stdin;
stage-001	project-villa-001	Schematic Design	1	completed	t	approved	\N	\N	\N	2026-07-31 00:00:00	2026-07-28 00:00:00	Initial concept drawings and site analysis	f	2026-09-19 11:10:18.275
stage-002	project-villa-001	Design Development	2	in_progress	t	pending	\N	\N	\N	2026-09-30 00:00:00	\N	Detailed drawings and material selection	f	2026-09-19 11:10:18.297
stage-003	project-villa-001	Working Drawings	3	pending	f	\N	\N	\N	\N	2026-11-30 00:00:00	\N	Complete set of construction drawings	f	2026-09-19 11:10:18.305
stage-004	project-villa-001	Site Supervision	4	pending	f	\N	\N	\N	\N	2027-03-31 00:00:00	\N	On-site supervision during construction	f	2026-09-19 11:10:18.315
stage2-001	project-villa-002	Concept Design	1	in_progress	t	pending	\N	\N	\N	2026-10-31 00:00:00	\N	Concept sketches and initial layout	f	2026-09-20 01:34:17.93
stage2-002	project-villa-002	Design Development	2	completed	t	\N	\N	\N	\N	2026-12-31 00:00:00	2026-10-01 11:30:24.749	Detailed drawings and specifications	f	2026-09-20 01:34:17.945
\.


--
-- Data for Name: ProjectTemplate; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."ProjectTemplate" (id, "firmId", name, description, "feeStructure", "defaultFileRequestWindowDays", "isDefault", "createdAt", "updatedAt") FROM stdin;
62a84861-7831-40b7-ae9f-831a5704b2c4	firm-coastal-001	Standard Residential	Standard workflow for residential architecture projects	per_stage	7	t	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
\.


--
-- Data for Name: Subtask; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."Subtask" (id, "taskId", title, completed, "createdById", "assignedToId", "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."Task" (id, "firmId", "projectId", "stageId", "assigneeId", "assignerId", title, description, status, priority, "dueDate", "startDate", "completedAt", "approvalStatus", "approvalNote", "approvedById", "isBlocked", "blockedReason", tags, "createdAt", "updatedAt", "startedAt", "order") FROM stdin;
task-001	firm-coastal-001	project-villa-001	stage-002	user-rahul-001	user-priya-001	Prepare floor plan drawings — Ground Floor	AutoCAD drawings for ground floor. Include all dimensions and room labels.	in_progress	high	2026-09-28 00:00:00	\N	\N	\N	\N	\N	f	\N	\N	2026-09-19 11:10:18.321	2026-09-19 11:10:18.321	\N	0
task-002	firm-coastal-001	project-villa-001	stage-002	user-rahul-001	user-priya-001	Prepare floor plan drawings — First Floor	\N	todo	high	2026-10-05 00:00:00	\N	\N	\N	\N	\N	f	\N	\N	2026-09-19 11:10:18.339	2026-09-19 11:10:18.339	\N	0
task-006	firm-coastal-001	project-villa-001	stage-002	user-priya-001	user-adil-001	Structural engineer coordination	\N	blocked	high	2026-09-25 00:00:00	\N	\N	\N	\N	\N	t	Waiting for soil test report from client	\N	2026-09-19 11:10:18.374	2026-09-19 11:10:18.374	\N	0
task-003	firm-coastal-001	project-villa-001	stage-002	user-ananya-001	user-priya-001	Interior material mood board	Compile material samples and finishes for client presentation.	review	normal	2026-09-22 00:00:00	\N	\N	\N	\N	\N	f	\N	\N	2026-09-19 11:10:18.349	2026-09-24 16:37:54.873	\N	0
task-005	firm-coastal-001	project-villa-001	stage-002	user-rahul-001	user-priya-001	Site visit and measurements verification	Cross-verify all site measurements against schematic drawings.	done	normal	2026-09-10 00:00:00	\N	2026-09-09 00:00:00	\N	\N	\N	f	\N	\N	2026-09-19 11:10:18.364	2026-09-24 16:37:54.873	\N	0
task2-002	firm-coastal-001	project-villa-002	stage2-001	user-meera-001	user-adil-001	Concept sketches — Exterior elevation	\N	todo	normal	2026-10-10 00:00:00	\N	\N	\N	\N	\N	f	\N	\N	2026-09-20 01:34:17.979	2026-09-24 16:37:54.873	\N	0
8ddd51d4-8153-45e6-886d-7456b34cb145	firm-coastal-001	project-villa-001	stage-002	user-adil-001	user-adil-001	design		todo	normal	2026-09-24 00:00:00	\N	\N	\N	\N	\N	f	\N	\N	2026-09-21 13:56:00.878	2026-09-24 16:37:54.873	\N	0
task-004	firm-coastal-001	project-villa-001	stage-002	user-priya-001	user-adil-001	Client presentation — Design Development	Prepare and conduct the design development presentation with the client.	todo	high	2026-10-10 00:00:00	\N	\N	\N	\N	\N	f	\N	\N	2026-09-19 11:10:18.357	2026-09-24 16:37:54.943	\N	0
task2-003	firm-coastal-001	project-villa-002	stage2-001	user-sanjay-001	user-adil-001	Fee proposal and agreement preparation	\N	done	high	2026-08-15 00:00:00	\N	2026-08-14 00:00:00	\N	\N	\N	f	\N	\N	2026-09-20 01:34:17.99	2026-09-24 16:37:54.943	\N	0
task2-001	firm-coastal-001	project-villa-002	stage2-001	user-faiz-001	user-adil-001	Site survey and topographic analysis	\N	completed	high	2026-10-01 11:30:23.247	\N	2026-10-01 11:30:24.703	approved	Approved	user-adil-001	f	\N	\N	2026-09-20 01:34:17.955	2026-10-01 11:30:24.704	\N	0
585d597b-2c30-412d-a8a6-4882c8557ff1	firm-coastal-001	project-villa-001	\N	user-priya-001	user-priya-001	Unassigned RBAC Task	\N	todo	normal	\N	\N	\N	\N	\N	\N	f	\N	\N	2026-10-01 11:59:51.444	2026-10-01 11:59:51.444	\N	0
abfdd9f7-ce2e-4d6b-85fc-eefbb7b0b26d	firm-coastal-001	project-villa-001	\N	user-priya-001	user-priya-001	Unassigned RBAC Task	\N	todo	normal	\N	\N	\N	\N	\N	\N	f	\N	\N	2026-10-01 13:32:39.025	2026-10-01 13:32:39.025	\N	0
\.


--
-- Data for Name: TaskAssignmentOverride; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."TaskAssignmentOverride" (id, "firmId", "taskId", "teamLeadId", "assigneeId", "requestedDueDate", "requiredLeadTimeDays", "actualLeadTimeDays", reason, "createdAt") FROM stdin;
\.


--
-- Data for Name: TaskReviewCycle; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."TaskReviewCycle" (id, "taskId", "reviewerId", "revisionNumber", remark, "statusRequested", "previousDueDate", "requestedDueDate", "createdAt") FROM stdin;
f840a58c-e382-41e8-8c1c-31a15932b827	task2-001	user-adil-001	1	Please fix	revision_requested	2026-09-30 00:00:00	2026-10-01 11:30:23.247	2026-10-01 11:30:23.31
1852efa3-eed3-42fa-9644-1b26469cd770	task2-001	user-adil-001	2	Approved	approved	2026-10-01 11:30:23.247	\N	2026-10-01 11:30:24.7
\.


--
-- Data for Name: TaskTimeSegment; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."TaskTimeSegment" (id, "sessionId", "projectId", "taskId", "startTime", "endTime", "durationMinutes", "taskCompletedOnSwitch") FROM stdin;
29694321-84f3-4379-b66f-503dc772bfb6	021a8c9b-bdf1-448d-baf6-4d907373b36a	p-rameshan-villa	t-rv-001	2026-09-19 11:44:00.364	2026-09-19 11:44:40.296	1	t
ad147fb8-bc6b-4ae8-83dc-017001b9ca74	021a8c9b-bdf1-448d-baf6-4d907373b36a	p-rameshan-villa	t-rv-005	2026-09-19 11:46:03.714	2026-09-19 11:46:12.856	0	f
da7e2cb0-b8eb-4575-8468-91d540bcf97d	883424bd-4124-474e-976c-7ce06f4a8d4a	project-villa-001	task-006	2026-09-20 01:53:40.366	2026-09-20 02:27:51.395	34	f
5e039c7e-c95a-4524-9c32-72288e1e350f	9d8d36f0-c545-4086-9cc5-81c0a4a2f31e	project-villa-001	task2-001	2026-10-01 12:03:59.229	\N	\N	f
\.


--
-- Data for Name: TemplateStage; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."TemplateStage" (id, "templateId", name, "order", "defaultDurationDays", description, "isClientApprovalRequired", "isPaymentMilestone", "paymentPercentage", "drawingTypesExpected", "createdAt", "updatedAt") FROM stdin;
60c50968-b2a4-4555-88aa-401a5b86a751	62a84861-7831-40b7-ae9f-831a5704b2c4	Schematic Design	1	21	\N	t	f	\N	\N	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
eb7cc245-2e2b-4c96-881b-429966040b3b	62a84861-7831-40b7-ae9f-831a5704b2c4	Design Development	2	30	\N	t	f	\N	\N	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
3ba4aa28-09e4-412f-8c1c-b1016505eb22	62a84861-7831-40b7-ae9f-831a5704b2c4	Working Drawings	3	45	\N	f	f	\N	\N	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
454e15a1-ba2c-49fe-93b0-0c20b435764c	62a84861-7831-40b7-ae9f-831a5704b2c4	Tender	4	14	\N	f	f	\N	\N	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
55369f3f-217b-4511-af2b-c011371c646e	62a84861-7831-40b7-ae9f-831a5704b2c4	Construction	5	180	\N	f	f	\N	\N	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
1ffdb93d-e27b-45a0-97a7-8c9a5718f195	62a84861-7831-40b7-ae9f-831a5704b2c4	Final Handover	6	7	\N	t	f	\N	\N	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
\.


--
-- Data for Name: TemplateTask; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."TemplateTask" (id, "stageId", title, description, "order", priority, "createdAt", "updatedAt") FROM stdin;
8fba12c0-1d85-4975-b2e8-6a60d840c6a7	60c50968-b2a4-4555-88aa-401a5b86a751	Site Analysis & Measurements	\N	1	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
8a989106-6924-4984-818e-f57394a15811	60c50968-b2a4-4555-88aa-401a5b86a751	Initial Floor Plans (Options A & B)	\N	3	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
6f3b93e1-c552-4342-95fa-7b2337a48f18	eb7cc245-2e2b-4c96-881b-429966040b3b	Refined Floor Plans	\N	1	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
bc382ccc-8847-43c3-8c10-012e60458bbd	eb7cc245-2e2b-4c96-881b-429966040b3b	3D Massing & Exterior Elevations	\N	2	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
ead18ce0-f6bc-47ae-ac94-e994cd43fc41	3ba4aa28-09e4-412f-8c1c-b1016505eb22	GFC Floor Plans & Sections	\N	1	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
e9e900d5-e3d4-4fd8-b058-7af6e56d840f	3ba4aa28-09e4-412f-8c1c-b1016505eb22	Detailed MEP Drawings	\N	3	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
d65f6146-9141-44db-b1fd-ccacc82e26b7	454e15a1-ba2c-49fe-93b0-0c20b435764c	Prepare Bill of Quantities (BOQ)	\N	1	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
c3b87559-4c91-4bc9-b71a-a6c4e6fb95a6	454e15a1-ba2c-49fe-93b0-0c20b435764c	Evaluate Contractor Bids	\N	3	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
3d8ceceb-e7a9-416b-88c7-3f518f18c4cc	55369f3f-217b-4511-af2b-c011371c646e	Site Handover & Marking	\N	1	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
8f553f58-c442-4b6a-aa9a-263ce3881808	55369f3f-217b-4511-af2b-c011371c646e	Plinth Level Check	\N	2	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
e6b058f3-e0d9-428e-a42e-caba40f04833	55369f3f-217b-4511-af2b-c011371c646e	Roof Slab Casting Site Visit	\N	3	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
354cdb03-66fc-4dc3-911c-a434544dab2f	1ffdb93d-e27b-45a0-97a7-8c9a5718f195	Punch List Walkthrough	\N	1	high	2026-09-21 15:25:07.516	2026-09-21 15:25:07.516
25706cb7-9006-43fd-bac1-5762ee26dcf6	60c50968-b2a4-4555-88aa-401a5b86a751	Zoning & Concept Sketches	\N	2	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
d17766f3-ab0b-4032-844b-8331f171fde1	60c50968-b2a4-4555-88aa-401a5b86a751	Client Presentation - Concept	\N	4	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
89a34469-dacc-44f4-b041-796ddec6eddd	eb7cc245-2e2b-4c96-881b-429966040b3b	Basic MEP Coordination Layouts	\N	3	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
54a82e6e-fada-423b-80b4-3b1bac45650e	eb7cc245-2e2b-4c96-881b-429966040b3b	Client Presentation - 3D Walkthrough	\N	4	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
25c888aa-0b7f-4a56-804f-3887d44e97f9	3ba4aa28-09e4-412f-8c1c-b1016505eb22	Joinery & Interior Details	\N	4	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
95c0eee9-1772-488a-a288-6d80652617fc	3ba4aa28-09e4-412f-8c1c-b1016505eb22	Door & Window Schedules	\N	5	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
0208d7d2-6d6d-4a3a-a96f-4fdedcfab8c2	454e15a1-ba2c-49fe-93b0-0c20b435764c	Issue Tender Documents to Contractors	\N	2	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
88f269fe-af5a-405c-a0c2-a1fdaa98ed42	55369f3f-217b-4511-af2b-c011371c646e	Flooring & Finishes Selection	\N	4	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
c5c1376d-04a8-4f26-9f5e-4998f1bf6e4e	1ffdb93d-e27b-45a0-97a7-8c9a5718f195	As-Built Drawings Compilation	\N	2	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
9a535cf8-3ebe-4e7b-8bbf-db5d80114591	1ffdb93d-e27b-45a0-97a7-8c9a5718f195	Project Closure Sign-off	\N	3	normal	2026-09-21 15:25:07.516	2026-09-24 16:37:54.954
f2b3a132-da78-4e7f-afd2-6fca616e780c	3ba4aa28-09e4-412f-8c1c-b1016505eb22	Structural Drawings (from Consultant)	\N	2	high	2026-09-21 15:25:07.516	2026-09-24 16:37:54.967
\.


--
-- Data for Name: TimeLog; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."TimeLog" (id, "firmId", "userId", "projectId", phase, "startTime", "endTime", "durationMinutes", notes, date, "isEdited", "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public."User" (id, "firmId", name, email, phone, role, designation, "avatarInitials", "avatarColor", "costRatePerHour", "joinedAt", status, "discontinuedAt", "passwordHash") FROM stdin;
a8406759-78d5-46da-ae37-93c471457fe2	398e6257-48e3-46f6-9ee7-20836445fa1e	Admin A	1790855386273admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:49:46.439	active	\N	$2b$10$rrOMT.pgLFozQrZLiv9jlO597nPzb//f.BtJlLcRpKiBOqmJyA06.
78b28393-5b77-4b13-90c1-544b1e265ac3	b30a3b11-d824-41a0-874f-e13359a10e8b	Admin B	1790855386273admin@firmb.com	\N	admin	\N	\N	\N	0	2026-10-01 11:49:46.606	active	\N	$2b$10$JUk2g.Qjdpk0UbccGjR/K.fzetorPT5Dhbvt7x.wY1oHSugn3LVMa
c4360f51-5913-4244-9af0-f6034c0cea22	fe687734-8744-4465-a431-2ea9a8a37993	Admin A	1790855407607admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:50:07.76	active	\N	$2b$10$aqOl1LPnqIy4rEc6q8qnaeJjJWZbMwv1UM0z5D69HSzwqA4E1kKPG
0cf086f5-d7f5-405a-94ab-6c4495812c86	70ea055b-34ec-4175-99de-ef5bf2664253	Admin A	1790855441210admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:50:41.387	active	\N	$2b$10$GfsLtEtdandt79yHhex9d.hrg62N49x6Y6mli4himpfei9qs2U.qC
30701346-ecc0-414e-b196-ad8e8ed91cc2	f3b8bc69-99dd-44d7-86f7-0788341cfb28	Admin A	1790855472920admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:51:13.073	active	\N	$2b$10$BtDMg67Y31a0xtKCagE6zO5qKQWvDwf89HB.1ggVwD4QTf69OIeHy
97c8015e-9f57-422e-8adc-e4c5f8a7f8d5	382d5aa0-c313-4dee-adc9-c9b7d9c94bfd	Admin A	1790855491803admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:51:31.971	active	\N	$2b$10$YhZYohIDAfaDPEb2LmDSX.UEdVFmmqKKjSYRdo1fllGXFt4WIbiJi
f285cd60-aa01-4ace-93a2-9535a2020650	7a5513a8-2f10-4ad9-a6b3-7e61b21c13d7	Admin A	1790855515562admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:51:55.764	active	\N	$2b$10$tX9xLvLJJ3Bft8hFC/OZMOD1HfyFwA0HG7Yf.7p0R01E3QChv0M4S
72b5eedc-d779-4e2d-a2ba-3f3adf25b4e8	8f7d683d-ea3f-47d6-81d0-cc423955f3a3	Admin A	1790861553748admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 13:32:34.186	active	\N	$2b$10$mawuqkeK3lWmYx9fvNWVlOGn939yiYG3Ss7rp9VEBFlEo/EF9Q1ci
user-priya-001	firm-coastal-001	Priya Nair	priya@coastaldesign.in	+91 98470 55002	team_lead	Senior Architect	PN	#3A86FF	1800	2026-09-19 11:10:18.164	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
user-rahul-001	firm-coastal-001	Rahul Menon	rahul@coastaldesign.in	+91 98470 55003	staff	Architectural Draughtsman	RM	#8338EC	900	2026-09-19 11:10:18.18	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
user-ananya-001	firm-coastal-001	Ananya Krishnan	ananya@coastaldesign.in	+91 98470 55004	staff	Interior Designer	AK	#06D6A0	1100	2026-09-19 11:10:18.198	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
user-sanjay-001	firm-coastal-001	Sanjay Thomas	sanjay@coastaldesign.in	+91 98470 55005	accounts	Accounts Manager	ST	#FFB703	800	2026-09-19 11:10:18.212	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
user-meera-001	firm-coastal-001	Meera Suresh	meera@coastaldesign.in	+91 98470 55006	staff	Architect	MS	#FF6B6B	1200	2026-09-20 01:34:17.826	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
user-faiz-001	firm-coastal-001	Mohammed Faiz	faiz@coastaldesign.in	+91 98470 55007	staff	Civil Engineer	MF	#4CC9F0	1000	2026-09-20 01:34:17.853	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
user-adil-001	firm-coastal-001	Adil Rahman	adil@coastaldesign.in	+91 98470 55001	admin	Principal Architect	AR	#E85D04	2500	2026-09-19 11:10:18.136	active	\N	$2b$10$ZS4zTnY1aAfAocmemhyP9OvB2/jd2x8Fii9RlXClgMuCNxd1pXyUi
11a3c9b5-1466-4ec9-97f7-f131fee3861f	12f2902c-4a36-45c8-960f-644a4814726b	Admin A	admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:48:31.06	active	\N	$2b$10$mQIlaASTRqFRVb1PE07Alex0tbobTOy4C6L95CQfcLNIhdbHlWkZ6
2a139907-411c-47ae-8c5e-fc53124a72f5	8ded49d6-a655-492f-abe9-e742b6e712da	Admin A	1790855323095admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:48:43.219	active	\N	$2b$10$JlutrRbAr/D7K3/tZ/JxNOCH18PniNmN5cK3bWlkxw2qLEaxJgRw.
76ce0671-b8cf-4796-8695-00d5f49bf2d8	2d535cc2-3768-4085-a7f3-fe7fa8dbafe1	Admin B	1790855323226admin@firmb.com	\N	admin	\N	\N	\N	0	2026-10-01 11:48:43.367	active	\N	$2b$10$T0XduKoTZ2d60FoHwxL3Fu0uGK9BuyNpLnZRpGc7P5cZNyiGg5TzC
52b3c157-7901-48fa-b6d0-03f10b86496e	18c9abb8-c581-4ea4-bc7f-08e799dd0350	Admin A	1790855347790admin@firma.com	\N	admin	\N	\N	\N	0	2026-10-01 11:49:07.925	active	\N	$2b$10$u5fUggAyWUjVrwvauWiLMuf6YP1cM25zxMUkvoW2.j8r/3uYHZblG
872af449-20eb-4919-9536-cfe1479606b0	a9bb115d-1443-4a14-996b-cec1e7f99ff8	Admin B	1790855347790admin@firmb.com	\N	admin	\N	\N	\N	0	2026-10-01 11:49:08.078	active	\N	$2b$10$wvLdIPGge/eWoKJj/mExke0GD2EevH8dIKC2o6oVFZBNn6vaGwXEW
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: elscore
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
9a02054f-3d37-49d3-ab4f-73665e8664c3	b71cf9f547e4021b25a5cfc28f4b09a64b63d16647df467bdb2541f016961d37	2026-10-01 13:43:50.012682+00	20261001000000_add_started_at		\N	2026-10-01 13:43:50.012682+00	0
7387720a-011d-4750-be21-0daf4052da1e	4e730abc7e3c797a93cf387b7a19e01cfa4f423cf179cdc6cb5e61e30b65300d	2026-10-01 13:43:52.056065+00	20261001000001_rls_policies		\N	2026-10-01 13:43:52.056065+00	0
\.


--
-- Name: ActivityLog ActivityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_pkey" PRIMARY KEY (id);


--
-- Name: AttendanceSession AttendanceSession_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."AttendanceSession"
    ADD CONSTRAINT "AttendanceSession_pkey" PRIMARY KEY (id);


--
-- Name: BreakRecord BreakRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."BreakRecord"
    ADD CONSTRAINT "BreakRecord_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: Firm Firm_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Firm"
    ADD CONSTRAINT "Firm_pkey" PRIMARY KEY (id);


--
-- Name: PlatformAdmin PlatformAdmin_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."PlatformAdmin"
    ADD CONSTRAINT "PlatformAdmin_pkey" PRIMARY KEY (id);


--
-- Name: ProjectStaff ProjectStaff_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectStaff"
    ADD CONSTRAINT "ProjectStaff_pkey" PRIMARY KEY ("projectId", "userId");


--
-- Name: ProjectStage ProjectStage_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectStage"
    ADD CONSTRAINT "ProjectStage_pkey" PRIMARY KEY (id);


--
-- Name: ProjectTemplate ProjectTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectTemplate"
    ADD CONSTRAINT "ProjectTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: Subtask Subtask_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Subtask"
    ADD CONSTRAINT "Subtask_pkey" PRIMARY KEY (id);


--
-- Name: TaskAssignmentOverride TaskAssignmentOverride_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskAssignmentOverride"
    ADD CONSTRAINT "TaskAssignmentOverride_pkey" PRIMARY KEY (id);


--
-- Name: TaskReviewCycle TaskReviewCycle_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskReviewCycle"
    ADD CONSTRAINT "TaskReviewCycle_pkey" PRIMARY KEY (id);


--
-- Name: TaskTimeSegment TaskTimeSegment_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskTimeSegment"
    ADD CONSTRAINT "TaskTimeSegment_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: TemplateStage TemplateStage_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TemplateStage"
    ADD CONSTRAINT "TemplateStage_pkey" PRIMARY KEY (id);


--
-- Name: TemplateTask TemplateTask_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TemplateTask"
    ADD CONSTRAINT "TemplateTask_pkey" PRIMARY KEY (id);


--
-- Name: TimeLog TimeLog_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TimeLog"
    ADD CONSTRAINT "TimeLog_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: ActivityLog_createdAt_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "ActivityLog_createdAt_idx" ON public."ActivityLog" USING btree ("createdAt");


--
-- Name: ActivityLog_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "ActivityLog_firmId_idx" ON public."ActivityLog" USING btree ("firmId");


--
-- Name: ActivityLog_projectId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "ActivityLog_projectId_idx" ON public."ActivityLog" USING btree ("projectId");


--
-- Name: ActivityLog_userId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "ActivityLog_userId_idx" ON public."ActivityLog" USING btree ("userId");


--
-- Name: AttendanceSession_date_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "AttendanceSession_date_idx" ON public."AttendanceSession" USING btree (date);


--
-- Name: AttendanceSession_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "AttendanceSession_firmId_idx" ON public."AttendanceSession" USING btree ("firmId");


--
-- Name: AttendanceSession_userId_date_key; Type: INDEX; Schema: public; Owner: elscore
--

CREATE UNIQUE INDEX "AttendanceSession_userId_date_key" ON public."AttendanceSession" USING btree ("userId", date);


--
-- Name: AttendanceSession_userId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "AttendanceSession_userId_idx" ON public."AttendanceSession" USING btree ("userId");


--
-- Name: BreakRecord_sessionId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "BreakRecord_sessionId_idx" ON public."BreakRecord" USING btree ("sessionId");


--
-- Name: Client_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Client_firmId_idx" ON public."Client" USING btree ("firmId");


--
-- Name: Firm_slug_key; Type: INDEX; Schema: public; Owner: elscore
--

CREATE UNIQUE INDEX "Firm_slug_key" ON public."Firm" USING btree (slug);


--
-- Name: PlatformAdmin_email_key; Type: INDEX; Schema: public; Owner: elscore
--

CREATE UNIQUE INDEX "PlatformAdmin_email_key" ON public."PlatformAdmin" USING btree (email);


--
-- Name: ProjectStage_projectId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "ProjectStage_projectId_idx" ON public."ProjectStage" USING btree ("projectId");


--
-- Name: ProjectTemplate_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "ProjectTemplate_firmId_idx" ON public."ProjectTemplate" USING btree ("firmId");


--
-- Name: Project_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Project_firmId_idx" ON public."Project" USING btree ("firmId");


--
-- Name: Project_status_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Project_status_idx" ON public."Project" USING btree (status);


--
-- Name: Subtask_taskId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Subtask_taskId_idx" ON public."Subtask" USING btree ("taskId");


--
-- Name: TaskAssignmentOverride_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TaskAssignmentOverride_firmId_idx" ON public."TaskAssignmentOverride" USING btree ("firmId");


--
-- Name: TaskAssignmentOverride_teamLeadId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TaskAssignmentOverride_teamLeadId_idx" ON public."TaskAssignmentOverride" USING btree ("teamLeadId");


--
-- Name: TaskReviewCycle_reviewerId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TaskReviewCycle_reviewerId_idx" ON public."TaskReviewCycle" USING btree ("reviewerId");


--
-- Name: TaskReviewCycle_taskId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TaskReviewCycle_taskId_idx" ON public."TaskReviewCycle" USING btree ("taskId");


--
-- Name: TaskTimeSegment_sessionId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TaskTimeSegment_sessionId_idx" ON public."TaskTimeSegment" USING btree ("sessionId");


--
-- Name: TaskTimeSegment_taskId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TaskTimeSegment_taskId_idx" ON public."TaskTimeSegment" USING btree ("taskId");


--
-- Name: Task_assigneeId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Task_assigneeId_idx" ON public."Task" USING btree ("assigneeId");


--
-- Name: Task_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Task_firmId_idx" ON public."Task" USING btree ("firmId");


--
-- Name: Task_projectId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Task_projectId_idx" ON public."Task" USING btree ("projectId");


--
-- Name: Task_status_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "Task_status_idx" ON public."Task" USING btree (status);


--
-- Name: TemplateStage_templateId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TemplateStage_templateId_idx" ON public."TemplateStage" USING btree ("templateId");


--
-- Name: TemplateTask_stageId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TemplateTask_stageId_idx" ON public."TemplateTask" USING btree ("stageId");


--
-- Name: TimeLog_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TimeLog_firmId_idx" ON public."TimeLog" USING btree ("firmId");


--
-- Name: TimeLog_projectId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TimeLog_projectId_idx" ON public."TimeLog" USING btree ("projectId");


--
-- Name: TimeLog_userId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "TimeLog_userId_idx" ON public."TimeLog" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: elscore
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_firmId_idx; Type: INDEX; Schema: public; Owner: elscore
--

CREATE INDEX "User_firmId_idx" ON public."User" USING btree ("firmId");


--
-- Name: ActivityLog ActivityLog_firmId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_firmId_fkey" FOREIGN KEY ("firmId") REFERENCES public."Firm"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ActivityLog ActivityLog_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ActivityLog ActivityLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AttendanceSession AttendanceSession_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."AttendanceSession"
    ADD CONSTRAINT "AttendanceSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BreakRecord BreakRecord_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."BreakRecord"
    ADD CONSTRAINT "BreakRecord_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."AttendanceSession"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Client Client_firmId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_firmId_fkey" FOREIGN KEY ("firmId") REFERENCES public."Firm"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectStaff ProjectStaff_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectStaff"
    ADD CONSTRAINT "ProjectStaff_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectStaff ProjectStaff_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectStaff"
    ADD CONSTRAINT "ProjectStaff_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectStage ProjectStage_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectStage"
    ADD CONSTRAINT "ProjectStage_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectTemplate ProjectTemplate_firmId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."ProjectTemplate"
    ADD CONSTRAINT "ProjectTemplate_firmId_fkey" FOREIGN KEY ("firmId") REFERENCES public."Firm"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Project Project_firmId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_firmId_fkey" FOREIGN KEY ("firmId") REFERENCES public."Firm"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_teamLeadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_teamLeadId_fkey" FOREIGN KEY ("teamLeadId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Project Project_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ProjectTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Subtask Subtask_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Subtask"
    ADD CONSTRAINT "Subtask_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaskAssignmentOverride TaskAssignmentOverride_assigneeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskAssignmentOverride"
    ADD CONSTRAINT "TaskAssignmentOverride_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TaskAssignmentOverride TaskAssignmentOverride_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskAssignmentOverride"
    ADD CONSTRAINT "TaskAssignmentOverride_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaskAssignmentOverride TaskAssignmentOverride_teamLeadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskAssignmentOverride"
    ADD CONSTRAINT "TaskAssignmentOverride_teamLeadId_fkey" FOREIGN KEY ("teamLeadId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TaskReviewCycle TaskReviewCycle_reviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskReviewCycle"
    ADD CONSTRAINT "TaskReviewCycle_reviewerId_fkey" FOREIGN KEY ("reviewerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TaskReviewCycle TaskReviewCycle_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskReviewCycle"
    ADD CONSTRAINT "TaskReviewCycle_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaskTimeSegment TaskTimeSegment_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TaskTimeSegment"
    ADD CONSTRAINT "TaskTimeSegment_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."AttendanceSession"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_assigneeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Task Task_assignerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_assignerId_fkey" FOREIGN KEY ("assignerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Task Task_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_stageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_stageId_fkey" FOREIGN KEY ("stageId") REFERENCES public."ProjectStage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TemplateStage TemplateStage_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TemplateStage"
    ADD CONSTRAINT "TemplateStage_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ProjectTemplate"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TemplateTask TemplateTask_stageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TemplateTask"
    ADD CONSTRAINT "TemplateTask_stageId_fkey" FOREIGN KEY ("stageId") REFERENCES public."TemplateStage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TimeLog TimeLog_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TimeLog"
    ADD CONSTRAINT "TimeLog_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TimeLog TimeLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."TimeLog"
    ADD CONSTRAINT "TimeLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_firmId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: elscore
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_firmId_fkey" FOREIGN KEY ("firmId") REFERENCES public."Firm"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ActivityLog; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."ActivityLog" ENABLE ROW LEVEL SECURITY;

--
-- Name: AttendanceSession; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."AttendanceSession" ENABLE ROW LEVEL SECURITY;

--
-- Name: BreakRecord; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."BreakRecord" ENABLE ROW LEVEL SECURITY;

--
-- Name: Client; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."Client" ENABLE ROW LEVEL SECURITY;

--
-- Name: Firm; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."Firm" ENABLE ROW LEVEL SECURITY;

--
-- Name: PlatformAdmin; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."PlatformAdmin" ENABLE ROW LEVEL SECURITY;

--
-- Name: Project; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."Project" ENABLE ROW LEVEL SECURITY;

--
-- Name: ProjectStaff; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."ProjectStaff" ENABLE ROW LEVEL SECURITY;

--
-- Name: ProjectStage; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."ProjectStage" ENABLE ROW LEVEL SECURITY;

--
-- Name: ProjectTemplate; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."ProjectTemplate" ENABLE ROW LEVEL SECURITY;

--
-- Name: Subtask; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."Subtask" ENABLE ROW LEVEL SECURITY;

--
-- Name: Task; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."Task" ENABLE ROW LEVEL SECURITY;

--
-- Name: TaskAssignmentOverride; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."TaskAssignmentOverride" ENABLE ROW LEVEL SECURITY;

--
-- Name: TaskReviewCycle; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."TaskReviewCycle" ENABLE ROW LEVEL SECURITY;

--
-- Name: TaskTimeSegment; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."TaskTimeSegment" ENABLE ROW LEVEL SECURITY;

--
-- Name: TemplateStage; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."TemplateStage" ENABLE ROW LEVEL SECURITY;

--
-- Name: TemplateTask; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."TemplateTask" ENABLE ROW LEVEL SECURITY;

--
-- Name: TimeLog; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."TimeLog" ENABLE ROW LEVEL SECURITY;

--
-- Name: User; Type: ROW SECURITY; Schema: public; Owner: elscore
--

ALTER TABLE public."User" ENABLE ROW LEVEL SECURITY;

--
-- Name: Task deny_all; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY deny_all ON public."Task" USING (false);


--
-- Name: ActivityLog firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."ActivityLog" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: AttendanceSession firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."AttendanceSession" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: Client firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."Client" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: Firm firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."Firm" USING ((id = current_setting('app.current_firm_id'::text, true)));


--
-- Name: Project firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."Project" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: ProjectTemplate firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."ProjectTemplate" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: Task firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."Task" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: TaskAssignmentOverride firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."TaskAssignmentOverride" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: TimeLog firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."TimeLog" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: User firm_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY firm_isolation ON public."User" USING (("firmId" = current_setting('app.current_firm_id'::text, true)));


--
-- Name: BreakRecord parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."BreakRecord" USING ((EXISTS ( SELECT 1
   FROM public."AttendanceSession"
  WHERE (("AttendanceSession".id = "BreakRecord"."sessionId") AND ("AttendanceSession"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: ProjectStaff parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."ProjectStaff" USING ((EXISTS ( SELECT 1
   FROM public."Project"
  WHERE (("Project".id = "ProjectStaff"."projectId") AND ("Project"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: ProjectStage parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."ProjectStage" USING ((EXISTS ( SELECT 1
   FROM public."Project"
  WHERE (("Project".id = "ProjectStage"."projectId") AND ("Project"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: Subtask parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."Subtask" USING ((EXISTS ( SELECT 1
   FROM public."Task"
  WHERE (("Task".id = "Subtask"."taskId") AND ("Task"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: TaskReviewCycle parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."TaskReviewCycle" USING ((EXISTS ( SELECT 1
   FROM public."Task"
  WHERE (("Task".id = "TaskReviewCycle"."taskId") AND ("Task"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: TaskTimeSegment parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."TaskTimeSegment" USING ((EXISTS ( SELECT 1
   FROM public."AttendanceSession"
  WHERE (("AttendanceSession".id = "TaskTimeSegment"."sessionId") AND ("AttendanceSession"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: TemplateStage parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."TemplateStage" USING ((EXISTS ( SELECT 1
   FROM public."ProjectTemplate"
  WHERE (("ProjectTemplate".id = "TemplateStage"."templateId") AND ("ProjectTemplate"."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: TemplateTask parent_isolation; Type: POLICY; Schema: public; Owner: elscore
--

CREATE POLICY parent_isolation ON public."TemplateTask" USING ((EXISTS ( SELECT 1
   FROM (public."TemplateStage" ts
     JOIN public."ProjectTemplate" pt ON ((ts."templateId" = pt.id)))
  WHERE ((ts.id = "TemplateTask"."stageId") AND (pt."firmId" = current_setting('app.current_firm_id'::text, true))))));


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO archos_app;
GRANT USAGE ON SCHEMA public TO archos_platform;
GRANT USAGE ON SCHEMA public TO archos_app_role;


--
-- Name: TABLE "ActivityLog"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."ActivityLog" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ActivityLog" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ActivityLog" TO archos_platform;


--
-- Name: TABLE "AttendanceSession"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."AttendanceSession" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."AttendanceSession" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."AttendanceSession" TO archos_platform;


--
-- Name: TABLE "BreakRecord"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."BreakRecord" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."BreakRecord" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."BreakRecord" TO archos_platform;


--
-- Name: TABLE "Client"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."Client" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Client" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Client" TO archos_platform;


--
-- Name: TABLE "Firm"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."Firm" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Firm" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Firm" TO archos_platform;


--
-- Name: TABLE "PlatformAdmin"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."PlatformAdmin" TO archos_platform;


--
-- Name: TABLE "Project"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."Project" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Project" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Project" TO archos_platform;


--
-- Name: TABLE "ProjectStaff"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."ProjectStaff" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ProjectStaff" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ProjectStaff" TO archos_platform;


--
-- Name: TABLE "ProjectStage"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."ProjectStage" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ProjectStage" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ProjectStage" TO archos_platform;


--
-- Name: TABLE "ProjectTemplate"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."ProjectTemplate" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ProjectTemplate" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."ProjectTemplate" TO archos_platform;


--
-- Name: TABLE "Subtask"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."Subtask" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Subtask" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Subtask" TO archos_platform;


--
-- Name: TABLE "Task"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."Task" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Task" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Task" TO archos_platform;


--
-- Name: TABLE "TaskAssignmentOverride"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."TaskAssignmentOverride" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TaskAssignmentOverride" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TaskAssignmentOverride" TO archos_platform;


--
-- Name: TABLE "TaskReviewCycle"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."TaskReviewCycle" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TaskReviewCycle" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TaskReviewCycle" TO archos_platform;


--
-- Name: TABLE "TaskTimeSegment"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."TaskTimeSegment" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TaskTimeSegment" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TaskTimeSegment" TO archos_platform;


--
-- Name: TABLE "TemplateStage"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."TemplateStage" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TemplateStage" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TemplateStage" TO archos_platform;


--
-- Name: TABLE "TemplateTask"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."TemplateTask" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TemplateTask" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TemplateTask" TO archos_platform;


--
-- Name: TABLE "TimeLog"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."TimeLog" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TimeLog" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."TimeLog" TO archos_platform;


--
-- Name: TABLE "User"; Type: ACL; Schema: public; Owner: elscore
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public."User" TO archos_app_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."User" TO archos_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."User" TO archos_platform;


--
-- PostgreSQL database dump complete
--

\unrestrict tCkD6cIffsebCOUzBscNtt4iHd09ADoteFuuWQx5vB6aaGryvd8Rj9EJ059ZQIj

