﻿
const fs = require("fs");
let content = fs.readFileSync("src/components/providers/DBProvider.tsx", "utf-8");

content = content.replace(
  /\/\/ Upsert users\s*for \(const u of zustandUsers\) \{/,
  `// Wipe ghost users to prevent legacy clashes\n          firmState.users = [];\n\n          // Upsert users\n          for (const u of zustandUsers) {`
);

fs.writeFileSync("src/components/providers/DBProvider.tsx", content);
console.log("Patched DBProvider");

