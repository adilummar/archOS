import { redirect } from "next/navigation";

export default function Home() {
  // Directly bypass the old firm-selection mockup and route straight to the actual firm login
  redirect("/cda/login");
}
