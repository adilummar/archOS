import { redirect } from "next/navigation";

export default function ContractorRoot() {
  redirect("/contractor/login");
}
