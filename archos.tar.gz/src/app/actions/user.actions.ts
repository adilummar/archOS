"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";

// ── GET all staff for a firm ─────────────────────────────────────────────
export async function getStaff(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.user.findMany({
    where: { firmId: currentUser.firmId, status: "active" },
    orderBy: { name: "asc" },
  });
}

// ── GET a single user ────────────────────────────────────────────────────
export async function getUser(userId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.user.findUnique({
    where: { id: userId },
    include: {
      assignedTasks: {
        include: { project: { select: { name: true } } },
        orderBy: { dueDate: "asc" },
        take: 10,
      },
      projectsAsLead: { select: { id: true, name: true, status: true } },
    },
  });
}

// ── CREATE staff member ──────────────────────────────────────────────────
export async function createUser(data: {
  firmId: string;
  name: string;
  email: string;
  phone?: string;
  role: string;
  designation?: string;
  costRatePerHour?: number;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const initials = data.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
  const colors = ["#E85D04", "#3A86FF", "#8338EC", "#06D6A0", "#FFB703"];
  const avatarColor = colors[Math.floor(Math.random() * colors.length)];

  const user = await prisma.user.create({
    data: { ...data, avatarInitials: initials, avatarColor },
  });

  revalidatePath("/[firmSlug]/settings", "page");
  return user;
}

// ── UPDATE staff member ──────────────────────────────────────────────────
export async function updateUser(
  userId: string,
  data: Partial<{
    name: string;
    phone: string;
    role: string;
    designation: string;
    costRatePerHour: number;
    status: string;
    discontinuedAt: Date;
  }>
) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const user = await prisma.user.update({ where: { id: userId }, data });
  revalidatePath("/[firmSlug]/settings", "page");
  return user;
}

// ── GET staff assigned to a project ─────────────────────────────────────
export async function getProjectStaff(projectId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.projectStaff.findMany({
    where: { projectId },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          role: true,
          designation: true,
          avatarInitials: true,
          avatarColor: true,
        },
      },
    },
  });
}
