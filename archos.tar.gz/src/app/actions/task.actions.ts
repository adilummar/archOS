﻿"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";

// â”€â”€ GET all tasks for a project â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function getTasksByProject(projectId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.task.findMany({
    where: { projectId },
    include: {
      assignee: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
      assigner: { select: { id: true, name: true } },
      subtasks: { orderBy: { createdAt: "asc" } }, reviewCycles: true,
      stage: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

// â”€â”€ GET all tasks for a firm (used by DBProvider to hydrate task store) â”€â”€â”€
export async function getAllTasksByFirm(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.task.findMany({
    where: { firmId },
    include: {
      subtasks: { orderBy: { createdAt: "asc" } }, reviewCycles: true,
    },
    orderBy: { createdAt: "desc" },
  });
}

// â”€â”€ GET all tasks for a staff member â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function getTasksByUser(userId: string, firmId: string, userEmail?: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  // Resolve real DB user ID
  let realUserId = userId;
  if (userEmail) {
    const dbUser = await prisma.user.findUnique({ where: { email: userEmail }, select: { id: true, firmId: true } });
    if (dbUser) {
      realUserId = dbUser.id;
      firmId = dbUser.firmId; // also ensure firmId is correct
    }
  }

  return prisma.task.findMany({
    where: { assigneeId: realUserId, firmId },
    include: {
      project: { select: { id: true, name: true } },
      subtasks: true,
    },
    orderBy: [{ dueDate: "asc" }, { priority: "desc" }],
  });
}

// â”€â”€ GET all tasks for a firm (admin view) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function getTasksByFirm(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.task.findMany({
    where: { firmId },
    include: {
      assignee: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
      project: { select: { id: true, name: true } },
      stage: { select: { id: true, name: true } },
      subtasks: true,
    },
    orderBy: { createdAt: "desc" },
  });
}

// â”€â”€ CREATE task â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function createTask(data: {
  firmId: string;
  projectId: string;
  stageId?: string;
  assigneeId: string;
  assignerId: string;
  title: string;
  description?: string;
  priority?: string;
  dueDate?: Date;
  startDate?: Date;
  tags?: string[];
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  console.log("createTask called with data:", data);
  const task = await prisma.task.create({
    data: {
      ...data,
      status: "todo",
    },
    include: {
      assignee: { select: { id: true, name: true } },
      project: { select: { name: true } },
    },
  });

  // Log the creation
  await prisma.activityLog.create({
    data: {
      firmId: data.firmId,
      userId: data.assignerId,
      projectId: data.projectId,
      entity: "task",
      entityId: task.id,
      action: "created",
      description: `Task "${task.title}" created and assigned to ${task.assignee.name}`,
    },
  });

  revalidatePath("/[firmSlug]/projects/[projectId]", "page");
  revalidatePath("/[firmSlug]/tasks", "page");
  return task;
}

// â”€â”€ UPDATE task â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function updateTask(
  taskId: string,
  data: Partial<{
    title: string;
    description: string;
    status: string;
    priority: string;
    assigneeId: string;
    dueDate: Date;
    startDate: Date;
    stageId: string;
    isBlocked: boolean;
    blockedReason: string;
    approvalStatus: string;
    approvalNote: string;
    approvedById: string;
    completedAt: Date;
    tags: string[];
  }>,
  firmId: string,
  actorId?: string
) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const existing = await prisma.task.findUnique({
    where: { id: taskId },
    include: { assignee: { select: { name: true } } },
  });

  const task = await prisma.task.update({
    where: { id: taskId },
    data: {
      ...data,
      completedAt:
        data.status === "done" && !existing?.completedAt ? new Date() : data.completedAt,
    },
  });

  // Log status changes specifically
  if (data.status && existing?.status !== data.status) {
    await prisma.activityLog.create({
      data: { firmId: currentUser.firmId,
        userId: actorId,
        projectId: task.projectId,
        entity: "task",
        entityId: taskId,
        action: "status_changed",
        description: `Task "${existing?.title}" moved from ${existing?.status} â†’ ${data.status}`,
      },
    });
  }

  revalidatePath("/[firmSlug]/projects/[projectId]", "page");
  revalidatePath("/[firmSlug]/tasks", "page");
  return task;
}

// â”€â”€ DELETE task â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function deleteTask(taskId: string, firmId: string, actorId?: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const existing = await prisma.task.findUnique({ where: { id: taskId } });
  await prisma.task.delete({ where: { id: taskId } });

  if (existing) {
    await prisma.activityLog.create({
      data: { firmId: currentUser.firmId,
        userId: actorId,
        projectId: existing.projectId,
        entity: "task",
        entityId: taskId,
        action: "deleted",
        description: `Task "${existing.title}" was deleted`,
      },
    });
  }

  revalidatePath("/[firmSlug]/projects/[projectId]", "page");
  revalidatePath("/[firmSlug]/tasks", "page");
}

// â”€â”€ ADD subtask â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function addSubtask(data: {
  taskId: string;
  title: string;
  createdById: string;
  assignedToId?: string;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.subtask.create({ data });
}

// â”€â”€ TOGGLE subtask completion â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function toggleSubtask(subtaskId: string, completed: boolean) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.subtask.update({
    where: { id: subtaskId },
    data: {
      completed,
      completedAt: completed ? new Date() : null,
    },
  });
}

// â”€â”€â”€ REVIEW TASK â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function reviewTask(
  taskId: string,
  reviewerId: string,
  firmId: string,
  data: {
    approvalStatus: "approved" | "revision_requested";
    approvalNote: string;
    newDueDate?: Date;
  }
) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const existing = await prisma.task.findUnique({
    where: { id: taskId },
    include: { reviewCycles: true }
  });

  if (!existing) throw new Error("Task not found");

  const revisionNumber = existing.reviewCycles.length + 1;

  const result = await prisma.$transaction([
    prisma.taskReviewCycle.create({
      data: {
        taskId,
        reviewerId,
        revisionNumber,
        remark: data.approvalNote,
        statusRequested: data.approvalStatus,
        previousDueDate: existing.dueDate,
        requestedDueDate: data.newDueDate
      }
    }),
    prisma.task.update({
      where: { id: taskId },
      data: {
        approvalStatus: data.approvalStatus,
        approvalNote: data.approvalNote,
        approvedById: reviewerId,
        status: data.approvalStatus === "approved" ? "approved" : "in_progress",
        dueDate: data.newDueDate || existing.dueDate
      }
    }),
    prisma.activityLog.create({
      data: { firmId: currentUser.firmId,
        userId: reviewerId,
        projectId: existing.projectId,
        entity: "task",
        entityId: taskId,
        action: data.approvalStatus,
        description: `Task reviewed: ${data.approvalStatus} (Rev #${revisionNumber})`
      }
    })
  ]);

  revalidatePath("/[firmSlug]/projects/[projectId]", "page");
  return result[1];
}

