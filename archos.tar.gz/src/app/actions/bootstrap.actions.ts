"use server";

/**
 * Server-side data bootstrap.
 * Called once from the app layout (server component wrapper) to
 * prefetch all data needed for the firm and pass it to the client.
 */

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";

export type BootstrapData = {
  firm: Awaited<ReturnType<typeof getFirmBySlug>>;
  staff: Awaited<ReturnType<typeof getStaffByFirm>>;
  projects: Awaited<ReturnType<typeof getProjectsByFirm>>;
};

/** Resolve firmSlug → firm record — uses slug column, falls back to name matching */
export async function getFirmBySlug(firmSlug: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");

  // 1. Try exact slug column match (fastest, most reliable)
  const bySlug = await prisma.firm.findUnique({ where: { slug: firmSlug } });
  if (bySlug) return bySlug;

  // 2. Fallback: match by slugified name (e.g. "coastal-design-associates")
  const firms = await prisma.firm.findMany();
  const byName = firms.find(
    (f) => f.name.toLowerCase().replace(/\s+/g, "-") === firmSlug || f.id === firmSlug
  );
  if (byName) return byName;

  // 3. Last resort: if only one firm exists, return it (single-tenant default)
  if (firms.length === 1) return firms[0];

  return null;
}

export async function getStaffByFirm(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");

  return prisma.user.findMany({
    where: { firmId, status: "active" },
    orderBy: { name: "asc" },
  });
}

export async function getProjectsByFirm(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");

  return prisma.project.findMany({
    where: { firmId },
    include: {
      client: { select: { id: true, name: true, company: true } },
      teamLead: {
        select: { id: true, name: true, avatarInitials: true, avatarColor: true },
      },
      staffMembers: {
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatarInitials: true,
              avatarColor: true,
            },
          },
        },
      },
      stages: { orderBy: { order: "asc" } },
      _count: { select: { tasks: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function getProjectWithTasks(projectId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");

  return prisma.project.findUnique({
    where: { id: projectId },
    include: {
      client: true,
      teamLead: {
        select: {
          id: true,
          name: true,
          avatarInitials: true,
          avatarColor: true,
          role: true,
        },
      },
      staffMembers: {
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatarInitials: true,
              avatarColor: true,
              role: true,
              designation: true,
            },
          },
        },
      },
      stages: { orderBy: { order: "asc" } },
      tasks: {
        include: {
          assignee: {
            select: {
              id: true,
              name: true,
              avatarInitials: true,
              avatarColor: true,
            },
          },
          subtasks: { orderBy: { createdAt: "asc" } },
          stage: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: "desc" },
      },
    },
  });
}
