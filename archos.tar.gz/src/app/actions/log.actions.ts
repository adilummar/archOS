"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";

// ── GLOBAL LOGS — all activity across the entire firm ────────────────────
export async function getGlobalLogs(firmId: string, limit = 100) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.activityLog.findMany({
    where: { firmId },
    include: {
      user: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
      project: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
}

// ── PROJECT LOGS — activity scoped to one project ────────────────────────
export async function getProjectLogs(projectId: string, limit = 100) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.activityLog.findMany({
    where: { projectId },
    include: {
      user: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
    },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
}

// ── USER LOGS — all activity by a specific staff member ──────────────────
export async function getUserLogs(userId: string, firmId: string, limit = 50) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.activityLog.findMany({
    where: { userId, firmId },
    include: {
      project: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
}

// ── USER LOGS BY DATE — fetch activity for a specific date ──────────────────
export async function getUserLogsByDate(userId: string, dateStr: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  // dateStr format: "YYYY-MM-DD"
  const start = new Date(`${dateStr}T00:00:00.000Z`);
  const end = new Date(`${dateStr}T23:59:59.999Z`);
  
  return prisma.activityLog.findMany({
    where: { 
      userId,
      createdAt: { gte: start, lte: end }
    },
    include: {
      project: { select: { id: true, name: true } }
    },
    orderBy: { createdAt: "desc" }
  });
}

// ── WRITE a log entry manually ───────────────────────────────────────────
export async function createLog(data: {
  firmId: string;
  userId?: string;
  projectId?: string;
  entity: string;
  entityId: string;
  action: string;
  description: string;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.activityLog.create({ data });
}

// ── TIME LOGS: Start session ─────────────────────────────────────────────
export async function startTimeLog(data: {
  firmId: string;
  userId: string;
  projectId: string;
  phase?: string;
  notes?: string;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.timeLog.create({
    data: {
      ...data,
      startTime: new Date(),
      date: new Date(),
    },
  });
}

// ── TIME LOGS: Stop session ──────────────────────────────────────────────
export async function stopTimeLog(timeLogId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const log = await prisma.timeLog.findUnique({ where: { id: timeLogId } });
  if (!log) return null;
  const endTime = new Date();
  const durationMinutes = Math.round(
    (endTime.getTime() - new Date(log.startTime).getTime()) / 60000
  );
  return prisma.timeLog.update({
    where: { id: timeLogId },
    data: { endTime, durationMinutes },
  });
}

// ── TIME LOGS: Get by project ────────────────────────────────────────────
export async function getTimeLogsByProject(projectId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.timeLog.findMany({
    where: { projectId },
    include: {
      user: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
    },
    orderBy: { date: "desc" },
  });
}

// ── TIME LOGS: Get by user ───────────────────────────────────────────────
export async function getTimeLogsByUser(userId: string, firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.timeLog.findMany({
    where: { userId, firmId },
    include: {
      project: { select: { id: true, name: true } },
    },
    orderBy: { date: "desc" },
  });
}

// ── GLOBAL LOG SUMMARY: stats for dashboard ──────────────────────────────
export async function getLogStats(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const [totalLogs, todayLogs, projectCount, taskCount] = await Promise.all([
    prisma.activityLog.count({ where: { firmId } }),
    prisma.activityLog.count({
      where: { firmId: currentUser.firmId,
        createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
      },
    }),
    prisma.project.count({ where: { firmId: currentUser.firmId, status: "active" } }),
    prisma.task.count({ where: { firmId: currentUser.firmId, status: { not: "done" } } }),
  ]);

  return { totalLogs, todayLogs, projectCount, taskCount };
}
