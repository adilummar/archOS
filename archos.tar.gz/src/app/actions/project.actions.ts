﻿"use server";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { revalidatePath } from "next/cache";

// â”€â”€ GET all projects for a firm â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function getProjects(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.project.findMany({
    where: { firmId },
    include: {
      client: { select: { name: true, company: true } },
      teamLead: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
      staffMembers: {
        include: {
          user: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
        },
      },
      stages: { orderBy: { order: "asc" } },
      _count: { select: { tasks: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

// â”€â”€ GET a single project â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function getProject(projectId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.project.findUnique({
    where: { id: projectId },
    include: {
      client: true,
      teamLead: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
      staffMembers: {
        include: {
          user: { select: { id: true, name: true, avatarInitials: true, avatarColor: true, role: true } },
        },
      },
      stages: { orderBy: { order: "asc" } },
      tasks: {
        include: {
          assignee: { select: { id: true, name: true, avatarInitials: true, avatarColor: true } },
          subtasks: true,
        },
        orderBy: { createdAt: "desc" },
      },
    },
  });
}

// â”€â”€ CREATE project â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function createProject(data: {
  firmId: string;
  name: string;
  clientId?: string;
  clientName?: string;
  teamLeadId?: string;
  staffIds?: string[];
  location?: string;
  description?: string;
  startDate?: Date;
  expectedEndDate?: Date;
  feeAgreed?: number;
  feeStructure?: string;
  projectValue?: number;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const { staffIds = [], ...rest } = data;

  const project = await prisma.project.create({
    data: {
      ...rest,
      staffMembers: {
        create: staffIds.map((userId) => ({ userId })),
      },
    },
    include: { stages: true },
  });

  // Log the creation
  await prisma.activityLog.create({
    data: {
      firmId: data.firmId,
      userId: data.teamLeadId,
      projectId: project.id,
      entity: "project",
      entityId: project.id,
      action: "created",
      description: `Project "${project.name}" was created`,
    },
  });

  revalidatePath("/[firmSlug]/projects", "page");
  return project;
}

// â”€â”€ UPDATE project â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function updateProject(
  projectId: string,
  data: Partial<{
    name: string;
    status: string;
    location: string;
    description: string;
    expectedEndDate: Date;
    actualEndDate: Date;
    teamLeadId: string;
    feeAgreed: number;
    chatEnabled: boolean;
  }>
) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const project = await prisma.project.update({
    where: { id: projectId },
    data,
  });
  revalidatePath("/[firmSlug]/projects", "page");
  return project;
}

// â”€â”€ ADD staff to project â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function addStaffToProject(projectId: string, userId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.projectStaff.upsert({
    where: { projectId_userId: { projectId, userId } },
    create: { projectId, userId },
    update: {},
  });
}

// â”€â”€ REMOVE staff from project â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function removeStaffFromProject(projectId: string, userId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.projectStaff.delete({
    where: { projectId_userId: { projectId, userId } },
  });
}

// â”€â”€ CREATE project stage â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function createProjectStage(data: {
  projectId: string;
  name: string;
  order: number;
  description?: string;
  isClientApprovalRequired?: boolean;
  plannedEndDate?: Date;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.projectStage.create({ data });
}

// â”€â”€ UPDATE stage status â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function updateStageStatus(
  stageId: string,
  status: string,
  firmId: string,
  userId?: string
) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const stage = await prisma.projectStage.update({
    where: { id: stageId },
    data: {
      status,
      actualEndDate: status === "completed" ? new Date() : undefined,
    },
    include: { project: true },
  });

  await prisma.activityLog.create({
    data: { firmId: currentUser.firmId,
      userId,
      projectId: stage.projectId,
      entity: "stage",
      entityId: stageId,
      action: "status_changed",
      description: `Stage "${stage.name}" moved to ${status}`,
    },
  });

  revalidatePath("/[firmSlug]/projects/[projectId]", "page");
  return stage;
}

// â”€â”€â”€ INSTANTIATE PROJECT FROM TEMPLATE â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export async function instantiateProjectFromTemplate(data: {
  firmId: string;
  templateId: string;
  name: string;
  clientId?: string;
  clientName?: string;
  teamLeadId?: string;
  staffIds?: string[];
  location?: string;
  description?: string;
  startDate?: Date;
  expectedEndDate?: Date;
  feeAgreed?: number;
  projectValue?: number;
}) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const { staffIds = [], templateId, ...rest } = data;

  let template = await prisma.projectTemplate.findUnique({
    where: { id: templateId },
    include: {
      stages: {
        include: {
          tasks: true
        }
      }
    }
  });

  if (!template) { template = await prisma.projectTemplate.findFirst({ where: { firmId: data.firmId }, include: { stages: { include: { tasks: true } } } }); if (!template) throw new Error("Template not found"); }

  const project = await prisma.project.create({
    data: {
      ...rest,
      templateId: template.id,
      feeStructure: template.feeStructure,
      fileRequestWindowDays: template.defaultFileRequestWindowDays,
      staffMembers: {
        create: staffIds.map((userId) => ({ userId })),
      },
    }
  });

  for (const [index, tStage] of template.stages.entries()) {
    const stage = await prisma.projectStage.create({
      data: {
        projectId: project.id,
        name: tStage.name,
        order: tStage.order,
        description: tStage.description,
        isClientApprovalRequired: tStage.isClientApprovalRequired,
        status: index === 0 ? "in_progress" : "pending"
      }
    });

    for (const tTask of tStage.tasks) {
      await prisma.task.create({
        data: {
          firmId: project.firmId,
          projectId: project.id,
          stageId: stage.id,
          title: tTask.title,
          description: tTask.description,
          priority: tTask.priority,
          assigneeId: rest.teamLeadId || staffIds[0],
          assignerId: rest.teamLeadId || staffIds[0],
        }
      });
    }
  }

  await prisma.activityLog.create({
    data: {
      firmId: data.firmId,
      userId: data.teamLeadId,
      projectId: project.id,
      entity: "project",
      entityId: project.id,
      action: "created",
      description: `Project "${project.name}" was instantiated from template "${template.name}"`,
    },
  });

  revalidatePath("/[firmSlug]/projects", "page");
  return project;
}


// ─── UPDATE PROJECT TEMPLATE ─────────────────────────────────────
export async function updateProjectTemplate(
  firmId: string,
  projectId: string,
  newTemplateId: string,
  actorId?: string
) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  const project = await prisma.project.findUnique({ where: { id: projectId } });
  if (!project) throw new Error("Project not found");

  const template = await prisma.projectTemplate.findUnique({
    where: { id: newTemplateId },
    include: {
      stages: {
        include: {
          tasks: true
        }
      }
    }
  });
  if (!template) throw new Error("Template not found");

  await prisma.$transaction([
    prisma.taskReviewCycle.deleteMany({ where: { task: { projectId } } }),
    prisma.subtask.deleteMany({ where: { task: { projectId } } }),
    prisma.task.deleteMany({ where: { projectId } }),
    prisma.projectStage.deleteMany({ where: { projectId } }),

    prisma.project.update({
      where: { id: projectId },
      data: { templateId: newTemplateId }
    })
  ]);

  for (const [index, tStage] of template.stages.entries()) {
    const stage = await prisma.projectStage.create({
      data: {
        projectId,
        name: tStage.name,
        order: tStage.order,
        description: tStage.description,
        isClientApprovalRequired: tStage.isClientApprovalRequired,
        status: index === 0 ? "in_progress" : "pending"
      }
    });

    for (const tTask of tStage.tasks) {
      await prisma.task.create({
        data: { firmId: currentUser.firmId,
          projectId,
          stageId: stage.id,
          title: tTask.title,
          description: tTask.description,
          priority: tTask.priority,
          assigneeId: project.teamLeadId || actorId || "", 
          assignerId: actorId || project.teamLeadId || "",
        }
      });
    }
  }

  if (actorId) {
    await prisma.activityLog.create({
      data: { firmId: currentUser.firmId,
        userId: actorId,
        projectId,
        entity: "project",
        entityId: projectId,
        action: "updated",
        description: `Project template changed to "${template.name}". All tasks were replaced.`,
      },
    });
  }

  revalidatePath("/[firmSlug]/projects", "page");
  revalidatePath("/[firmSlug]/projects/[projectId]", "page");
  return true;
}


export async function getTemplatesByFirm(firmId: string) {
  const session = await getSession();
  if (!session.userId) throw new Error("Unauthorized");
  const currentUser = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, firmId: true, role: true } });
  if (!currentUser) throw new Error("Unauthorized");

  return prisma.projectTemplate.findMany({
    where: { firmId: currentUser.firmId },
    include: {
      stages: { orderBy: { order: "asc" }, include: { tasks: { orderBy: { order: "asc" } } } },
    },
    orderBy: { createdAt: "desc" },
  });
}

