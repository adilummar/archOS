﻿
import { useState } from "react";
import { Drawer } from "../shared/Drawer";
import { useFirmStore } from "@/lib/store/firm.store";
import { useAuthStore } from "@/lib/store/auth.store";
import { useProjectStore } from "@/lib/store/project.store";
import { createTask } from "@/app/actions/task.actions";
import { toast } from "@/lib/store/toast.store";
import { format } from "date-fns";

interface Props {
  open: boolean;
  onClose: () => void;
  projectId: string;
}

export function NewTaskDrawer({ open, onClose, projectId }: Props) {
  const { user, firm } = useAuthStore();
  const { users } = useFirmStore();
  const { projects } = useProjectStore();
  
  const project = projects.find((p) => p.id === projectId);
  
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [stageId, setStageId] = useState("");
  const [assigneeId, setAssigneeId] = useState("");
  const [priority, setPriority] = useState("medium");
  const [dueDate, setDueDate] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Set default stage and assignee when opened
  if (open && !stageId && project?.stages.length) {
    setStageId(project.currentStageId || project.stages[0].id);
  }
  if (open && !assigneeId && user) {
    setAssigneeId(user.id);
  }

  const handleSubmit = async () => {
    if (!firm || !user) return;
    if (!title.trim()) return setError("Title is required");
    if (!stageId) return setError("Stage is required");
    if (!assigneeId) return setError("Assignee is required");

    setIsSubmitting(true);
    try {
      await createTask({
        firmId: firm.id,
        projectId,
        stageId,
        title: title.trim(),
        description: description.trim(),
        assigneeId,
        assignerId: user.id,
        priority,
        dueDate: dueDate ? new Date(dueDate) : undefined,
      });
      
      toast("Task created successfully", "success");
      onClose();
      window.location.reload();
    } catch (err: any) {
      setError(err.message || "Failed to create task");
    } finally {
      setIsSubmitting(false);
    }
  };

  const activeStaff = users.filter((u) => u.firmId === firm?.id && u.status === "active");

  return (
    <Drawer open={open} onClose={onClose} title="New Task" width={400}>
      <div style={{ padding: "24px 28px", display: "flex", flexDirection: "column", gap: 16 }}>
        {error && (
          <div style={{ padding: "10px", background: "var(--color-destructive)", color: "white", borderRadius: "var(--radius-sm)", fontSize: "13px" }}>
            {error}
          </div>
        )}

        <div>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 500, color: "var(--color-text-secondary)", marginBottom: 6 }}>Title</label>
          <input 
            type="text" 
            value={title} 
            onChange={(e) => setTitle(e.target.value)} 
            placeholder="E.g., Review floor plans"
            style={{ width: "100%", padding: "8px 12px", borderRadius: "var(--radius-sm)", border: "1px solid var(--color-border)", background: "var(--color-bg-input)", color: "var(--color-text-primary)" }}
          />
        </div>

        <div>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 500, color: "var(--color-text-secondary)", marginBottom: 6 }}>Stage</label>
          <select 
            value={stageId} 
            onChange={(e) => setStageId(e.target.value)}
            style={{ width: "100%", padding: "8px 12px", borderRadius: "var(--radius-sm)", border: "1px solid var(--color-border)", background: "var(--color-bg-input)", color: "var(--color-text-primary)" }}
          >
            {project?.stages.map((stage) => (
              <option key={stage.id} value={stage.id}>{stage.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 500, color: "var(--color-text-secondary)", marginBottom: 6 }}>Assignee</label>
          <select 
            value={assigneeId} 
            onChange={(e) => setAssigneeId(e.target.value)}
            style={{ width: "100%", padding: "8px 12px", borderRadius: "var(--radius-sm)", border: "1px solid var(--color-border)", background: "var(--color-bg-input)", color: "var(--color-text-primary)" }}
          >
            {activeStaff.map((staff) => (
              <option key={staff.id} value={staff.id}>{staff.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 500, color: "var(--color-text-secondary)", marginBottom: 6 }}>Priority</label>
          <select 
            value={priority} 
            onChange={(e) => setPriority(e.target.value)}
            style={{ width: "100%", padding: "8px 12px", borderRadius: "var(--radius-sm)", border: "1px solid var(--color-border)", background: "var(--color-bg-input)", color: "var(--color-text-primary)" }}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>

        <div>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 500, color: "var(--color-text-secondary)", marginBottom: 6 }}>Due Date</label>
          <input 
            type="date" 
            value={dueDate} 
            onChange={(e) => setDueDate(e.target.value)} 
            style={{ width: "100%", padding: "8px 12px", borderRadius: "var(--radius-sm)", border: "1px solid var(--color-border)", background: "var(--color-bg-input)", color: "var(--color-text-primary)" }}
          />
        </div>

        <div>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 500, color: "var(--color-text-secondary)", marginBottom: 6 }}>Description</label>
          <textarea 
            value={description} 
            onChange={(e) => setDescription(e.target.value)} 
            rows={3}
            style={{ width: "100%", padding: "8px 12px", borderRadius: "var(--radius-sm)", border: "1px solid var(--color-border)", background: "var(--color-bg-input)", color: "var(--color-text-primary)", resize: "vertical" }}
          />
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 16 }}>
          <button onClick={onClose} style={{ padding: "8px 16px", background: "transparent", border: "1px solid var(--color-border)", color: "var(--color-text-secondary)", borderRadius: "var(--radius-sm)", cursor: "pointer" }}>
            Cancel
          </button>
          <button onClick={handleSubmit} disabled={isSubmitting} style={{ padding: "8px 16px", background: "var(--color-accent)", border: "none", color: "white", borderRadius: "var(--radius-sm)", cursor: "pointer", opacity: isSubmitting ? 0.7 : 1 }}>
            {isSubmitting ? "Creating..." : "Create Task"}
          </button>
        </div>
      </div>
    </Drawer>
  );
}

