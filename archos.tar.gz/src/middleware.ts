import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { getIronSession } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session";

/**
 * Protected routes — any path that requires authentication.
 * Public routes — accessible without a session.
 */
const PUBLIC_PATHS = [
  "/api/auth/login",
  "/api/auth/logout",
  "/client",
  "/contractor",
  "/_next",
  "/favicon.ico",
];

function isPublicPath(pathname: string): boolean {
  // Login pages: /<firmSlug>/login
  if (pathname.match(/^\/[^/]+\/login$/)) return true;
  return PUBLIC_PATHS.some((p) => pathname.startsWith(p));
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Always allow public paths through
  if (isPublicPath(pathname)) {
    return NextResponse.next();
  }

  // Read session — iron-session decrypts and verifies the cookie server-side
  const res = NextResponse.next();
  const session = await getIronSession<SessionData>(await cookies(), sessionOptions);

  // No valid session → redirect to login
  if (!session.userId) {
    // Determine firm slug from path for redirect
    const slugMatch = pathname.match(/^\/([^/]+)\//);
    const firmSlug = slugMatch?.[1] ?? "login";

    // Avoid redirect loops for API routes
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const loginUrl = new URL(`/${firmSlug}/login`, req.url);
    return NextResponse.redirect(loginUrl);
  }

  return res;
}

export const config = {
  matcher: [
    /*
     * Match all paths except:
     * - Static files (_next/static, _next/image, favicon, etc.)
     * - The root landing page (/)
     */
    "/((?!_next/static|_next/image|favicon.ico|$).*)",
  ],
};
