﻿
const fs = require("fs");
let content = fs.readFileSync("src/app/[firmSlug]/login/page.tsx", "utf-8");

// We will replace the static firm lookup with DBProvider wrapping
if (!content.includes("<DBProvider")) {
  content = content.replace(
    /import \{ useFirmStore \} from "@\/lib\/store\/firm\.store";/,
    `import { useFirmStore } from "@/lib/store/firm.store";\nimport { DBProvider } from "@/components/providers/DBProvider";`
  );

  content = content.replace(
    /return \(\s*<>\s*<ToastProvider \/>/,
    `return (\n    <>\n      <ToastProvider />\n      <DBProvider firmSlug={firmSlug} />`
  );
  
  content = content.replace(
    /\{loading \? "Loading demo data\.\.\." : "Load Demo Data & Enter"\}/,
    `{loading ? "Loading..." : "Enter"}`
  );
}

fs.writeFileSync("src/app/[firmSlug]/login/page.tsx", content);
console.log("Patched login page with DBProvider");

