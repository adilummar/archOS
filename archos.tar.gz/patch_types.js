﻿
const fs = require("fs");
let content = fs.readFileSync("src/lib/store/types.ts", "utf8");
content = content.replace(
  /export interface TemplateStage \{([^}]+)\}/,
  `export interface TemplateTask {\n  id: string; stageId: string; title: string; description: string; order: number; priority: "low" | "medium" | "high" | "urgent";\n}\n\nexport interface TemplateStage {$1  tasks?: TemplateTask[];\n}`
);
fs.writeFileSync("src/lib/store/types.ts", content);

