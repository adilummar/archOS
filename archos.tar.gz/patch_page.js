﻿
const fs = require("fs");
let content = fs.readFileSync("src/app/[firmSlug]/(app)/projects/[projectId]/page.tsx", "utf-8");

// Import NewTaskDrawer
content = content.replace(
  `import { TasksTab } from "@/components/project/TasksTab";`,
  `import { TasksTab } from "@/components/project/TasksTab";\nimport { NewTaskDrawer } from "@/components/drawers/NewTaskDrawer";\nimport { Plus } from "lucide-react";`
);

// Add state
const stateTarget = `const [activeTab, setActiveTab] = useState<TabId>("overview");`;
const stateReplacement = `const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);`;
content = content.replace(stateTarget, stateReplacement);

// Add New Task button to Tab bar
const tabTarget = `{/* Tab bar */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            padding: "0 28px",
            gap: 0,
            overflowX: "auto",
          }}
        >
          {visibleTabs.map((tab) => {`;
          
const tabReplacement = `{/* Tab bar */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            borderBottom: "1px solid var(--color-border)",
            paddingRight: 28,
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              padding: "0 28px",
              gap: 0,
              overflowX: "auto",
              flex: 1,
            }}
          >
            {visibleTabs.map((tab) => {`;
content = content.replace(tabTarget, tabReplacement);

// Add the right side of the Tab bar
const tabEndTarget = `              </button>
            );
          })}
        </div>
      </div>`;

const tabEndReplacement = `              </button>
            );
          })}
          </div>

          {/* Right actions */}
          {activeTab === "tasks" && (
            <button
              onClick={() => setIsNewTaskOpen(true)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                background: "var(--color-accent)",
                color: "white",
                border: "none",
                borderRadius: "var(--radius-sm)",
                padding: "6px 12px",
                fontSize: "12px",
                fontWeight: 500,
                cursor: "pointer",
                whiteSpace: "nowrap",
                marginLeft: 16,
              }}
            >
              <Plus size={14} strokeWidth={2} /> New Task
            </button>
          )}
        </div>
      </div>`;
content = content.replace(tabEndTarget, tabEndReplacement);

// Render the drawer
const renderTarget = `{/* Tab content */}
      <div style={{ padding: "24px 28px", minHeight: 400 }}>{renderTab()}</div>
    </>`;
    
const renderReplacement = `{/* Tab content */}
      <div style={{ padding: "24px 28px", minHeight: 400 }}>{renderTab()}</div>

      {isNewTaskOpen && (
        <NewTaskDrawer
          open={isNewTaskOpen}
          onClose={() => setIsNewTaskOpen(false)}
          projectId={project.id}
        />
      )}
    </>`;
content = content.replace(renderTarget, renderReplacement);

fs.writeFileSync("src/app/[firmSlug]/(app)/projects/[projectId]/page.tsx", content);
console.log("Patched page.tsx");

