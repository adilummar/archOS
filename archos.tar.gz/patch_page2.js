﻿
const fs = require("fs");
let content = fs.readFileSync("src/app/[firmSlug]/(app)/projects/[projectId]/page.tsx", "utf-8");

// Import NewTaskDrawer
content = content.replace(
  /import\s*\{\s*TasksTab\s*\}\s*from\s*"@\/components\/project\/TasksTab";/,
  `import { TasksTab } from "@/components/project/TasksTab";\nimport { NewTaskDrawer } from "@/components/drawers/NewTaskDrawer";\nimport { Plus } from "lucide-react";`
);

// Add state
content = content.replace(
  /const\s*\[activeTab,\s*setActiveTab\]\s*=\s*useState<TabId>\("overview"\);/,
  `const [activeTab, setActiveTab] = useState<TabId>("overview");\n  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);`
);

// Tab bar container
content = content.replace(
  /\{\/\*\s*Tab\s*bar\s*\*\/\}\s*<div\s*style=\{\{\s*display:\s*"flex",\s*alignItems:\s*"center",\s*padding:\s*"0\s*28px",\s*gap:\s*0,\s*overflowX:\s*"auto",\s*\}\}\s*>\s*\{visibleTabs\.map\(\(tab\)\s*=>\s*\{/,
  `{/* Tab bar wrapper */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            borderBottom: "1px solid var(--color-border)",
            paddingRight: 28,
          }}
        >
          {/* Tab bar */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              padding: "0 28px",
              gap: 0,
              overflowX: "auto",
              flex: 1,
            }}
          >
            {visibleTabs.map((tab) => {`
);

// End of Tab bar
content = content.replace(
  /\{\s*tab\.label\s*\}\s*<\/button>\s*\);\s*\}\)\}\s*<\/div>\s*<\/div>/,
  `{tab.label}
                </button>
              );
            })}
          </div>

          {/* Right actions */}
          {activeTab === "tasks" && (
            <button
              onClick={() => setIsNewTaskOpen(true)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                background: "var(--color-accent)",
                color: "white",
                border: "none",
                borderRadius: "var(--radius-sm)",
                padding: "6px 12px",
                fontSize: "12px",
                fontWeight: 500,
                cursor: "pointer",
                whiteSpace: "nowrap",
                marginLeft: 16,
              }}
            >
              <Plus size={14} strokeWidth={2} /> New Task
            </button>
          )}
        </div>
      </div>`
);

// Tab content
content = content.replace(
  /\{\/\*\s*Tab\s*content\s*\*\/\}\s*<div\s*style=\{\{\s*padding:\s*"24px\s*28px",\s*minHeight:\s*400\s*\}\}>\s*\{renderTab\(\)\}\s*<\/div>\s*<\/>/,
  `{/* Tab content */}
      <div style={{ padding: "24px 28px", minHeight: 400 }}>{renderTab()}</div>

      {isNewTaskOpen && (
        <NewTaskDrawer
          open={isNewTaskOpen}
          onClose={() => setIsNewTaskOpen(false)}
          projectId={project.id}
        />
      )}
    </>`
);

fs.writeFileSync("src/app/[firmSlug]/(app)/projects/[projectId]/page.tsx", content);
console.log("Patched page.tsx with regex");

